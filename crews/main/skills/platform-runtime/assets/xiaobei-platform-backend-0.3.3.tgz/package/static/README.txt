Business request registries and protocol descriptors are bundled here. Signature resources are provided by the Relay service.
